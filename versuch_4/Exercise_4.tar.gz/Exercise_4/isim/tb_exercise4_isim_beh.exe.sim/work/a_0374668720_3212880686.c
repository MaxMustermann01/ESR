/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
extern char *STD_STANDARD;
extern char *IEEE_P_1242562249;
static const char *ng2 = "/home/fel/Exercise_4/exercise4.vhd";
extern char *IEEE_P_2592010699;

char *ieee_p_1242562249_sub_180853171_1035706684(char *, char *, int , int );
unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
unsigned char ieee_p_2592010699_sub_1744673427_503743352(char *, char *, unsigned int , unsigned int );


char *work_a_0374668720_3212880686_sub_1818511259_3057020925(char *t1)
{
    char t2[144];
    char t10[32];
    char t19[1024];
    char t28[8];
    char t33[16];
    char *t0;
    char *t4;
    char *t5;
    unsigned int t6;
    char *t7;
    unsigned char t8;
    unsigned int t9;
    char *t11;
    char *t12;
    int t13;
    unsigned int t14;
    char *t15;
    int t16;
    char *t17;
    char *t18;
    char *t20;
    char *t21;
    char *t22;
    char *t23;
    char *t24;
    char *t25;
    char *t26;
    char *t27;
    char *t29;
    char *t30;
    int t31;
    int t32;
    char *t34;
    char *t35;
    int t36;
    char *t37;
    char *t38;
    int t39;
    unsigned int t40;
    unsigned int t41;
    char *t42;
    unsigned int t43;

LAB0:    t4 = xsi_get_transient_memory(1024U);
    memset(t4, 0, 1024U);
    t5 = t4;
    t6 = (8U * 1U);
    t7 = t5;
    memset(t7, (unsigned char)2, t6);
    t8 = (t6 != 0);
    if (t8 == 1)
        goto LAB2;

LAB3:    t11 = (t10 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 127;
    t12 = (t11 + 4U);
    *((int *)t12) = 0;
    t12 = (t11 + 8U);
    *((int *)t12) = -1;
    t13 = (0 - 127);
    t14 = (t13 * -1);
    t14 = (t14 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t14;
    t12 = (t10 + 16U);
    t15 = (t12 + 0U);
    *((int *)t15) = 7;
    t15 = (t12 + 4U);
    *((int *)t15) = 0;
    t15 = (t12 + 8U);
    *((int *)t15) = -1;
    t16 = (0 - 7);
    t14 = (t16 * -1);
    t14 = (t14 + 1);
    t15 = (t12 + 12U);
    *((unsigned int *)t15) = t14;
    t15 = (t2 + 4U);
    t17 = (t1 + 5172);
    t18 = (t15 + 52U);
    *((char **)t18) = t17;
    t20 = (t15 + 36U);
    *((char **)t20) = t19;
    memcpy(t19, t4, 1024U);
    t21 = (t15 + 40U);
    t22 = (t17 + 44U);
    t23 = *((char **)t22);
    *((char **)t21) = t23;
    t24 = (t15 + 48U);
    *((unsigned int *)t24) = 1024U;
    t25 = (t2 + 72U);
    t26 = ((STD_STANDARD) + 240);
    t27 = (t25 + 52U);
    *((char **)t27) = t26;
    t29 = (t25 + 36U);
    *((char **)t29) = t28;
    *((int *)t28) = 1;
    t30 = (t25 + 48U);
    *((unsigned int *)t30) = 4U;
    t31 = 0;
    t32 = 127;

LAB4:    if (t31 <= t32)
        goto LAB5;

LAB7:    t4 = (t15 + 36U);
    t5 = *((char **)t4);
    t8 = (1024U != 1024U);
    if (t8 == 1)
        goto LAB9;

LAB10:    t0 = xsi_get_transient_memory(1024U);
    memcpy(t0, t5, 1024U);

LAB1:    return t0;
LAB2:    t9 = (1024U / t6);
    xsi_mem_set_data(t5, t5, t6, t9);
    goto LAB3;

LAB5:    t34 = (t25 + 36U);
    t35 = *((char **)t34);
    t36 = *((int *)t35);
    t34 = ieee_p_1242562249_sub_180853171_1035706684(IEEE_P_1242562249, t33, t36, 8);
    t37 = (t15 + 36U);
    t38 = *((char **)t37);
    t39 = (t31 - 127);
    t14 = (t39 * -1);
    xsi_vhdl_check_range_of_index(127, 0, -1, t31);
    t40 = (8U * t14);
    t41 = (0 + t40);
    t37 = (t38 + t41);
    t42 = (t33 + 12U);
    t43 = *((unsigned int *)t42);
    t43 = (t43 * 1U);
    memcpy(t37, t34, t43);
    t4 = (t25 + 36U);
    t5 = *((char **)t4);
    t13 = *((int *)t5);
    t16 = (t13 + 1);
    t4 = (t25 + 36U);
    t7 = *((char **)t4);
    t4 = (t7 + 0);
    *((int *)t4) = t16;

LAB6:    if (t31 == t32)
        goto LAB7;

LAB8:    t13 = (t31 + 1);
    t31 = t13;
    goto LAB4;

LAB9:    xsi_size_not_matching(1024U, 1024U, 0);
    goto LAB10;

LAB11:;
}

static void work_a_0374668720_3212880686_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 3424U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(127, ng2);

LAB6:    t2 = (t0 + 4420);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 4420);
    *((int *)t5) = 0;
    xsi_set_current_line(128, ng2);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t6 = (t4 == (unsigned char)3);
    if (t6 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(131, ng2);
    t2 = (t0 + 1052U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 4512);
    t5 = (t2 + 32U);
    t7 = *((char **)t5);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB2;

LAB5:    t3 = (t0 + 1304U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(129, ng2);
    t2 = (t0 + 4512);
    t5 = (t2 + 32U);
    t7 = *((char **)t5);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void work_a_0374668720_3212880686_p_1(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    t1 = (t0 + 3560U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(138, ng2);

LAB6:    t2 = (t0 + 4428);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 4428);
    *((int *)t5) = 0;
    xsi_set_current_line(139, ng2);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t6 = (t4 == (unsigned char)3);
    if (t6 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(142, ng2);
    t2 = (t0 + 1236U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t2 = (t0 + 4548);
    t5 = (t2 + 32U);
    t7 = *((char **)t5);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = t4;
    xsi_driver_first_trans_fast(t2);

LAB9:    goto LAB2;

LAB5:    t3 = (t0 + 1396U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(140, ng2);
    t2 = (t0 + 4548);
    t5 = (t2 + 32U);
    t7 = *((char **)t5);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    *((unsigned char *)t9) = (unsigned char)0;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

}

static void work_a_0374668720_3212880686_p_2(char *t0)
{
    char *t1;
    unsigned char t2;
    char *t3;
    char *t4;
    char *t5;
    int t6;
    int t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    char *t11;
    char *t12;
    char *t13;
    char *t14;
    char *t15;

LAB0:    xsi_set_current_line(149, ng2);
    t1 = (t0 + 1304U);
    t2 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t2 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4436);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(150, ng2);
    t3 = (t0 + 2880U);
    t4 = *((char **)t3);
    t3 = (t0 + 1512U);
    t5 = *((char **)t3);
    t6 = *((int *)t5);
    t7 = (t6 - 127);
    t8 = (t7 * -1);
    xsi_vhdl_check_range_of_index(127, 0, -1, t6);
    t9 = (8U * t8);
    t10 = (0 + t9);
    t3 = (t4 + t10);
    t11 = (t0 + 4584);
    t12 = (t11 + 32U);
    t13 = *((char **)t12);
    t14 = (t13 + 32U);
    t15 = *((char **)t14);
    memcpy(t15, t3, 8U);
    xsi_driver_first_trans_fast(t11);
    goto LAB3;

}

static void work_a_0374668720_3212880686_p_3(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    unsigned char t4;
    char *t5;
    char *t6;
    char *t7;
    char *t8;
    char *t9;

LAB0:    xsi_set_current_line(156, ng2);
    t1 = (t0 + 1420U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t4 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t3);
    t1 = (t0 + 4620);
    t5 = (t1 + 32U);
    t6 = *((char **)t5);
    t7 = (t6 + 32U);
    t8 = *((char **)t7);
    *((unsigned char *)t8) = t4;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(157, ng2);
    t1 = (t0 + 1396U);
    t3 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t1, 0U, 0U);
    if (t3 != 0)
        goto LAB2;

LAB4:
LAB3:    t1 = (t0 + 4444);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_set_current_line(158, ng2);
    t2 = (t0 + 2340U);
    t5 = *((char **)t2);
    t2 = (t0 + 4656);
    t6 = (t2 + 32U);
    t7 = *((char **)t6);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    memcpy(t9, t5, 4U);
    xsi_driver_first_trans_fast_port(t2);
    goto LAB3;

}

static void work_a_0374668720_3212880686_p_4(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    char *t11;
    static char *nl0[] = {&&LAB3, &&LAB4};

LAB0:    xsi_set_current_line(165, ng2);
    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4692);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(166, ng2);
    t1 = (t0 + 4728);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(167, ng2);
    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 4452);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(169, ng2);
    t4 = (t0 + 1880U);
    t5 = *((char **)t4);
    t8 = *((unsigned char *)t5);
    t9 = (t8 == (unsigned char)2);
    if (t9 != 0)
        goto LAB6;

LAB8:    xsi_set_current_line(173, ng2);
    t1 = (t0 + 4692);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(174, ng2);
    t1 = (t0 + 4728);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(177, ng2);
    t1 = (t0 + 1880U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)2);
    if (t8 != 0)
        goto LAB9;

LAB11:    xsi_set_current_line(181, ng2);
    t1 = (t0 + 4692);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(182, ng2);
    t1 = (t0 + 4728);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB10:    goto LAB2;

LAB5:    xsi_set_current_line(185, ng2);
    t1 = (t0 + 4692);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(170, ng2);
    t4 = (t0 + 4692);
    t6 = (t4 + 32U);
    t7 = *((char **)t6);
    t10 = (t7 + 32U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(171, ng2);
    t1 = (t0 + 4728);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB7;

LAB9:    xsi_set_current_line(178, ng2);
    t1 = (t0 + 4692);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(179, ng2);
    t1 = (t0 + 4728);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB10;

}

static void work_a_0374668720_3212880686_p_5(char *t0)
{
    char *t1;
    char *t2;
    unsigned char t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned char t8;
    unsigned char t9;
    char *t10;
    char *t11;
    static char *nl0[] = {&&LAB3, &&LAB4};

LAB0:    xsi_set_current_line(192, ng2);
    t1 = (t0 + 1144U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (t0 + 4764);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = t3;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(193, ng2);
    t1 = (t0 + 4800);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(194, ng2);
    t1 = (t0 + 1144U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t1 = (char *)((nl0) + t3);
    goto **((char **)t1);

LAB2:    t1 = (t0 + 4460);
    *((int *)t1) = 1;

LAB1:    return;
LAB3:    xsi_set_current_line(196, ng2);
    t4 = (t0 + 1972U);
    t5 = *((char **)t4);
    t8 = *((unsigned char *)t5);
    t9 = (t8 == (unsigned char)2);
    if (t9 != 0)
        goto LAB6;

LAB8:    xsi_set_current_line(200, ng2);
    t1 = (t0 + 4764);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(201, ng2);
    t1 = (t0 + 4800);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB7:    goto LAB2;

LAB4:    xsi_set_current_line(204, ng2);
    t1 = (t0 + 1972U);
    t2 = *((char **)t1);
    t3 = *((unsigned char *)t2);
    t8 = (t3 == (unsigned char)2);
    if (t8 != 0)
        goto LAB9;

LAB11:    xsi_set_current_line(208, ng2);
    t1 = (t0 + 4764);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(209, ng2);
    t1 = (t0 + 4800);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t1);

LAB10:    goto LAB2;

LAB5:    xsi_set_current_line(212, ng2);
    t1 = (t0 + 4764);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)0;
    xsi_driver_first_trans_fast(t1);
    goto LAB2;

LAB6:    xsi_set_current_line(197, ng2);
    t4 = (t0 + 4764);
    t6 = (t4 + 32U);
    t7 = *((char **)t6);
    t10 = (t7 + 32U);
    t11 = *((char **)t10);
    *((unsigned char *)t11) = (unsigned char)1;
    xsi_driver_first_trans_fast(t4);
    xsi_set_current_line(198, ng2);
    t1 = (t0 + 4800);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB7;

LAB9:    xsi_set_current_line(205, ng2);
    t1 = (t0 + 4764);
    t4 = (t1 + 32U);
    t5 = *((char **)t4);
    t6 = (t5 + 32U);
    t7 = *((char **)t6);
    *((unsigned char *)t7) = (unsigned char)1;
    xsi_driver_first_trans_fast(t1);
    xsi_set_current_line(206, ng2);
    t1 = (t0 + 4800);
    t2 = (t1 + 32U);
    t4 = *((char **)t2);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t1);
    goto LAB10;

}

static void work_a_0374668720_3212880686_p_6(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    unsigned char t4;
    char *t5;
    unsigned char t6;
    char *t7;
    char *t8;
    char *t9;
    int t10;
    unsigned char t11;
    unsigned char t12;
    int t13;
    int t14;
    char *t15;
    char *t16;

LAB0:    t1 = (t0 + 4240U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(218, ng2);

LAB6:    t2 = (t0 + 4468);
    *((int *)t2) = 1;
    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    t5 = (t0 + 4468);
    *((int *)t5) = 0;
    xsi_set_current_line(219, ng2);
    t2 = (t0 + 684U);
    t3 = *((char **)t2);
    t4 = *((unsigned char *)t3);
    t6 = (t4 == (unsigned char)3);
    if (t6 != 0)
        goto LAB8;

LAB10:    xsi_set_current_line(222, ng2);
    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t10 = *((int *)t3);
    t6 = (t10 < 127);
    if (t6 == 1)
        goto LAB14;

LAB15:    t4 = (unsigned char)0;

LAB16:    if (t4 != 0)
        goto LAB11;

LAB13:    t2 = (t0 + 1512U);
    t3 = *((char **)t2);
    t10 = *((int *)t3);
    t6 = (t10 == 127);
    if (t6 == 1)
        goto LAB19;

LAB20:    t4 = (unsigned char)0;

LAB21:    if (t4 != 0)
        goto LAB17;

LAB18:
LAB12:
LAB9:    goto LAB2;

LAB5:    t3 = (t0 + 1304U);
    t4 = ieee_p_2592010699_sub_1744673427_503743352(IEEE_P_2592010699, t3, 0U, 0U);
    if (t4 == 1)
        goto LAB4;
    else
        goto LAB6;

LAB7:    goto LAB5;

LAB8:    xsi_set_current_line(220, ng2);
    t2 = (t0 + 4836);
    t5 = (t2 + 32U);
    t7 = *((char **)t5);
    t8 = (t7 + 32U);
    t9 = *((char **)t8);
    *((int *)t9) = 0;
    xsi_driver_first_trans_fast(t2);
    goto LAB9;

LAB11:    xsi_set_current_line(223, ng2);
    t2 = (t0 + 1512U);
    t7 = *((char **)t2);
    t13 = *((int *)t7);
    t14 = (t13 + 1);
    t2 = (t0 + 4836);
    t8 = (t2 + 32U);
    t9 = *((char **)t8);
    t15 = (t9 + 32U);
    t16 = *((char **)t15);
    *((int *)t16) = t14;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

LAB14:    t2 = (t0 + 1696U);
    t5 = *((char **)t2);
    t11 = *((unsigned char *)t5);
    t12 = (t11 == (unsigned char)3);
    t4 = t12;
    goto LAB16;

LAB17:    xsi_set_current_line(225, ng2);
    t2 = (t0 + 4836);
    t7 = (t2 + 32U);
    t8 = *((char **)t7);
    t9 = (t8 + 32U);
    t15 = *((char **)t9);
    *((int *)t15) = 0;
    xsi_driver_first_trans_fast(t2);
    goto LAB12;

LAB19:    t2 = (t0 + 1696U);
    t5 = *((char **)t2);
    t11 = *((unsigned char *)t5);
    t12 = (t11 == (unsigned char)3);
    t4 = t12;
    goto LAB21;

}


void ieee_p_2592010699_sub_3130575329_503743352();

extern void work_a_0374668720_3212880686_init()
{
	static char *pe[] = {(void *)work_a_0374668720_3212880686_p_0,(void *)work_a_0374668720_3212880686_p_1,(void *)work_a_0374668720_3212880686_p_2,(void *)work_a_0374668720_3212880686_p_3,(void *)work_a_0374668720_3212880686_p_4,(void *)work_a_0374668720_3212880686_p_5,(void *)work_a_0374668720_3212880686_p_6};
	static char *se[] = {(void *)work_a_0374668720_3212880686_sub_1818511259_3057020925};
	xsi_register_didat("work_a_0374668720_3212880686", "isim/tb_exercise4_isim_beh.exe.sim/work/a_0374668720_3212880686.didat");
	xsi_register_executes(pe);
	xsi_register_subprogram_executes(se);
	xsi_register_resolution_function(1, 2, (void *)ieee_p_2592010699_sub_3130575329_503743352, 4);
}
