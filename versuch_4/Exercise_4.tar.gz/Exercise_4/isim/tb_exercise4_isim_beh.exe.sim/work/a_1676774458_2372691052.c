/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0xfbc00daa */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "/home/fel/Exercise_4/tb_exercise4.vhd";
extern char *IEEE_P_2592010699;
extern char *IEEE_P_3564397177;
extern char *STD_TEXTIO;

unsigned char ieee_p_2592010699_sub_1690584930_503743352(char *, unsigned char );
void ieee_p_3564397177_sub_1281154728_91900896(char *, char *, char *, char *, char *, unsigned char , int );


static void work_a_1676774458_2372691052_p_0(char *t0)
{
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    int64 t7;
    int64 t8;

LAB0:    t1 = (t0 + 1876U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(52, ng0);
    t2 = (t0 + 2244);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)2;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(53, ng0);
    t2 = (t0 + 1224U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 1776);
    xsi_process_wait(t2, t8);

LAB6:    *((char **)t1) = &&LAB7;

LAB1:    return;
LAB4:    xsi_set_current_line(54, ng0);
    t2 = (t0 + 2244);
    t3 = (t2 + 32U);
    t4 = *((char **)t3);
    t5 = (t4 + 32U);
    t6 = *((char **)t5);
    *((unsigned char *)t6) = (unsigned char)3;
    xsi_driver_first_trans_fast(t2);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 1224U);
    t3 = *((char **)t2);
    t7 = *((int64 *)t3);
    t8 = (t7 / 2);
    t2 = (t0 + 1776);
    xsi_process_wait(t2, t8);

LAB10:    *((char **)t1) = &&LAB11;
    goto LAB1;

LAB5:    goto LAB4;

LAB7:    goto LAB5;

LAB8:    goto LAB2;

LAB9:    goto LAB8;

LAB11:    goto LAB9;

}

static void work_a_1676774458_2372691052_p_1(char *t0)
{
    char t8[16];
    char t10[16];
    char t22[8];
    char *t1;
    char *t2;
    unsigned int t3;
    unsigned int t4;
    unsigned int t5;
    char *t6;
    char *t7;
    char *t9;
    char *t11;
    char *t12;
    int t13;
    unsigned int t14;
    unsigned char t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;
    char *t20;
    unsigned char t21;

LAB0:    xsi_set_current_line(62, ng0);
    t1 = (t0 + 960U);
    t2 = *((char **)t1);
    t3 = (7 - 3);
    t4 = (t3 * 1U);
    t5 = (0 + t4);
    t1 = (t2 + t5);
    t6 = (t0 + 776U);
    t7 = *((char **)t6);
    t9 = ((IEEE_P_2592010699) + 2312);
    t11 = (t10 + 0U);
    t12 = (t11 + 0U);
    *((int *)t12) = 3;
    t12 = (t11 + 4U);
    *((int *)t12) = 0;
    t12 = (t11 + 8U);
    *((int *)t12) = -1;
    t13 = (0 - 3);
    t14 = (t13 * -1);
    t14 = (t14 + 1);
    t12 = (t11 + 12U);
    *((unsigned int *)t12) = t14;
    t12 = (t0 + 3908U);
    t6 = xsi_base_array_concat(t6, t8, t9, (char)97, t1, t10, (char)97, t7, t12, (char)101);
    t14 = (4U + 4U);
    t15 = (8U != t14);
    if (t15 == 1)
        goto LAB2;

LAB3:    t16 = (t0 + 2280);
    t17 = (t16 + 32U);
    t18 = *((char **)t17);
    t19 = (t18 + 32U);
    t20 = *((char **)t19);
    memcpy(t20, t6, 8U);
    xsi_driver_first_trans_fast(t16);
    xsi_set_current_line(63, ng0);
    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t15 = *((unsigned char *)t2);
    t21 = (t15 == (unsigned char)3);
    if (t21 != 0)
        goto LAB4;

LAB6:
LAB5:    xsi_set_current_line(67, ng0);
    t1 = (t0 + 1052U);
    t2 = *((char **)t1);
    t15 = *((unsigned char *)t2);
    t21 = ieee_p_2592010699_sub_1690584930_503743352(IEEE_P_2592010699, t15);
    t1 = (t0 + 2316);
    t6 = (t1 + 32U);
    t7 = *((char **)t6);
    t9 = (t7 + 32U);
    t11 = *((char **)t9);
    *((unsigned char *)t11) = t21;
    xsi_driver_first_trans_fast(t1);
    t1 = (t0 + 2192);
    *((int *)t1) = 1;

LAB1:    return;
LAB2:    xsi_size_not_matching(8U, t14, 0);
    goto LAB3;

LAB4:    xsi_set_current_line(64, ng0);
    t1 = (t0 + 1912);
    t6 = (t0 + 1516U);
    t7 = (t0 + 960U);
    t9 = *((char **)t7);
    memcpy(t22, t9, 8U);
    t7 = (t0 + 3924U);
    ieee_p_3564397177_sub_1281154728_91900896(IEEE_P_3564397177, t1, t6, t22, t7, (unsigned char)0, 0);
    xsi_set_current_line(65, ng0);
    t1 = (t0 + 1912);
    t2 = ((STD_TEXTIO) + 848U);
    t6 = (t0 + 1516U);
    std_textio_writeline(STD_TEXTIO, t1, t2, t6);
    goto LAB5;

}


extern void work_a_1676774458_2372691052_init()
{
	static char *pe[] = {(void *)work_a_1676774458_2372691052_p_0,(void *)work_a_1676774458_2372691052_p_1};
	xsi_register_didat("work_a_1676774458_2372691052", "isim/tb_exercise4_isim_beh.exe.sim/work/a_1676774458_2372691052.didat");
	xsi_register_executes(pe);
}
