ghdl -a --ieee=standard ucDevPack.vhd 
ghdl -a --ieee=standard ucPack.vhd 
ghdl -a --ieee=standard xmlgen.vhd
ghdl -e --ieee=standard xmlgen
ghdl -r --ieee=standard xmlgen

