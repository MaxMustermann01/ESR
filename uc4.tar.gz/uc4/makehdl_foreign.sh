rm uc_tb_foreign uc_tb_foreign.o
gcc -c sigxchange.c
ghdl -a --ieee=standard ucDevPack.vhd 
ghdl -a --ieee=standard ucPack.vhd 
ghdl -a --ieee=standard hxxgen.vhd
ghdl -a --ieee=standard xmlgen.vhd
ghdl -a --ieee=standard promData.vhd 
for i in alu akku prom ram instrDecoder progCounter portIn portOut ucCore uc uc_tb_foreign; do ghdl -a --ieee=standard $i.vhd; done
ghdl -e -Wl,sigxchange.o --ieee=standard uc_tb_foreign
ghdl -r uc_tb_foreign --vcd=uc_tb_foreign.vcd --stop-time=50us

