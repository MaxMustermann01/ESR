/*
 * gcc -c -O2 sigxchange.c 
 * ghdl -e -Wl,sigxchange.o --ieee=synopsys uc_tb_foreign
*/

#include <stdio.h>

#define SULV_U  (0) /* Uninitialized   */
#define SULV_X  (1) /* Forcing Unknown */
#define SULV_0  (2) /* Forcing 0       */
#define SULV_1  (3) /* Forcing 1       */
#define SULV_Z  (4) /* High Impedance  */
#define SULV_W  (5) /* Weak Unknown    */
#define SULV_L  (6) /* Weak 0          */
#define SULV_H  (7) /* Weak 1          */
#define SULV__  (8) /* Don't care      */

//void sigxchange(char ckin[1])
//void sigxchange(char *cki, int dbgbits, char *dbg)

// constant dbgbits : integer := databits * 4 + 1 + 1 + opbits + instrbits + databits + addressbits;

#define SIZE 45

int inline binary(char c) {return (SULV_0 == c)?0:1;};

void sigxchange(char *cki, char *dbg)
{
  static int init = 1;
  static char clk = 0;
  static int cnt = 0;
  static FILE *f = NULL;
  static char *fn = "uc4.csv";
  int i;
  if (init) {
    init = 0;
    f = fopen(fn,"w"); 
    //debug <= dout_port & dout_ram & dout_alu & dout_akku & zf & cf & op & pwe & rwe & pcld & sel & instr_prom & data_prom & addr_prom;
    fprintf(f,"time;rst;stop;portOut;dout_port;dout_ram;dout_alu;dout_akku;zf;cf;op;pre;pwe;rwe;pcld;sel;instr_prom;data_prom;addr_prom\n");
  }
  if (!clk) {
  fprintf(f,"%6.6d;",cnt++);
    for (i=0;i<SIZE;i++){
      if (0 == i) fprintf(f,"\"");
      fprintf(f,"%1.1d",binary(dbg[i]));
      if (0 == i) fprintf(f,"\";\"");
      if (1 == i) fprintf(f,"\";\"");
      if (5 == i) fprintf(f,"\";\"");
      if (9 == i) fprintf(f,"\";\"");
      if (13 == i) fprintf(f,"\";\"");
      if (17 == i) fprintf(f,"\";\"");
      if (21 == i) fprintf(f,"\";\"");
      if (22 == i) fprintf(f,"\";\"");
      if (23 == i) fprintf(f,"\";\"");
      if (26 == i) fprintf(f,"\";\"");
      if (27 == i) fprintf(f,"\";\"");
      if (28 == i) fprintf(f,"\";\"");
      if (29 == i) fprintf(f,"\";\"");
      if (32 == i) fprintf(f,"\";\"");
      if (36 == i) fprintf(f,"\";\"");
      if (40 == i) fprintf(f,"\";\"");
 
    }
    fprintf(f,"\"\n");
    fflush(f);
  }
  cki[0] = (1 == clk) ? SULV_1 : SULV_0;
  clk ^= 1;
}
