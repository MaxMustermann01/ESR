ghdl -a --ieee=standard ucPack.vhd 
ghdl -a --ieee=standard ucDevPack.vhd 
ghdl -a --ieee=standard promData.vhd 
#for i in hxxgen alu akku prom ram instrDecoder progCounter portIn portOut uc uc_tb; do ghdl -a --ieee=synopsys $i.vhd;ghdl -e --ieee=synopsys $i; done
#for i in alu akku prom ram instrDecoder progCounter portIn portOut uc ucCore uc_tb; do ghdl -a --ieee=synopsys $i.vhd;ghdl -e --ieee=synopsys $i; done
for i in alu akku prom ram pwm instrDecoder progCounter portIn portOut ucCore uc uc_tb; do ghdl -a --ieee=standard $i.vhd;ghdl -e --ieee=standard $i; done
ghdl -r uc_tb --vcd=uc_tb.vcd --stop-time=100us

