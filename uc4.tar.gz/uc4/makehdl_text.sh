ghdl -a --ieee=standard ucDevPack.vhd 
ghdl -a --ieee=standard ucPack.vhd 
ghdl -a --ieee=standard xmlgen.vhd
ghdl -a --ieee=standard promData.vhd 
for i in alu akku prom ram instrDecoder progCounter portIn portOut ucCore uc uc_tb_text; do ghdl -a --ieee=standard $i.vhd;ghdl -e --ieee=standard $i; done
ghdl -r uc_tb_text --vcd=uc_tb_text.vcd --stop-time=100us

